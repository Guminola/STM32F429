#include "rtl.h"
#include "stdio.h"
//#include "stm32l1xx.h"
#include "stm32F4xx.h"
#include "stm32f429i_discovery_lcd.h"

/* Private functions ---------------------------------------------------------*/
int Enviar_Mensaje(char c);

//void LCD_Glass_ON(void);
