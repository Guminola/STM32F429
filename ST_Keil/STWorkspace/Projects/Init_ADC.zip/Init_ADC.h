/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx.h"	

#include "stm32F4xx_adc.h"

/* Private function prototypes -----------------------------------------------*/
void Init_ADC(void);