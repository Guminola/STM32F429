/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx.h"

#include "stm32f429i_discovery.h"
#include "stm32f429i_discovery_lcd.h"

/* Private function prototypes -----------------------------------------------*/
void Init_LCD(void);